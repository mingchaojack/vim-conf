public class Class
{
    public int attribute;
    public static void Main (string[] args)
    {
        int 九 = 9;
    }
}

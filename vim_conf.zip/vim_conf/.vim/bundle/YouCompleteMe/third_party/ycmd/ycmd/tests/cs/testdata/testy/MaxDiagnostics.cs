public class MaxDiagnostics
{
    public int test;
    public int test;
    public int test;
}

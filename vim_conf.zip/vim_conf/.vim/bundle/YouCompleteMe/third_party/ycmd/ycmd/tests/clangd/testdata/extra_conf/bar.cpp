#include "bar.h"

int main() {
    Structure structure;
    structure.
}

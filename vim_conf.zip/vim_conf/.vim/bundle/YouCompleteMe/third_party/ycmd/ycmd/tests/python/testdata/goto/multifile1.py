from multifile3 import my_function
from multifile2 import my_integer, my_function_alias

my_integer
my_function
my_function_alias

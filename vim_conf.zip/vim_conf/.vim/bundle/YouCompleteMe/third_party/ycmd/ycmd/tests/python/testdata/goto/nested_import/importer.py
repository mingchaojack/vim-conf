from basic import MyClass
from nested_import.to_import import import_me
from .to_import import relative

#ifndef DOCS
#define DOCS
/// docstring
void docstring_from_header_file();
#endif /* ifndef DOCS */

def Foo():
  """aafäö"""
  pass

Fo

x = '†'.cen

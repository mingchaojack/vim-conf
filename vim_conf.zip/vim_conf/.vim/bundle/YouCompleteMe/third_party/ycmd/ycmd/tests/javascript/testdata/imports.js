import func from "library";
import * as lib from "library";
import { func1, func2 } from "library";

func();


lib.func();


func1();
func2();

package com.ycmd.test;

public class App {

    public static void main(String[] args) {
        Person p = new Person();
        p.setName("Stella J.");
        p.setAge(29);
        System.out.println(p.getName() + "is " + p.getAge() + " years old.");
    }

}

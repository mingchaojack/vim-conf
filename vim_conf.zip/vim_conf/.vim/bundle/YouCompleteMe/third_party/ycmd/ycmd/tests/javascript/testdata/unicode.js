export class Bår {}

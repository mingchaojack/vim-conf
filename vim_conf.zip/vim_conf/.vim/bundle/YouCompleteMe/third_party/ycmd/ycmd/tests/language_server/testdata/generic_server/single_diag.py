def Settings(**kwargs):
  return {
           "config_sections": {
             "languageServerExample": {
               "maxNumberOfProblems": 1
             }
           }
         }

package com.test.wobble;

public interface Waggle {

}

def Settings( **kwargs ):
    return { 'ls': { 'java.rename.enabled' : False } }

define( ['lamelib/lame_widget'], function( lame_widget ) {

    return {
        options: {
            'test': 200
        },

        /**
         * This is a short documentation string
         */
        a_function: function( bar ) {
            return {
                a_value: 'baz'
            };
        }
    };

} );

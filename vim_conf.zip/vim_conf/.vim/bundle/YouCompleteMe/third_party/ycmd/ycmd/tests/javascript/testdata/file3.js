var bar = new Bar();
bar.testMethod();

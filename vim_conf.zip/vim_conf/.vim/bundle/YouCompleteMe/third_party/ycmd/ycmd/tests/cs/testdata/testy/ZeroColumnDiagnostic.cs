class Class{
    int Method()
}

from parent import P
class C( P ):
  def c( self ):
    self.from_base()
